# Budget+ (BudBud)

Plateforme suisse d'accompagnement budgétaire, pour particuliers et
professionnels (assistants sociaux, conseillers financiers, communes,
associations). Construit avec Next.js 14 (App Router), React, TypeScript,
Tailwind CSS, React Hook Form + Zod, Recharts, SheetJS et jsPDF.

## Démarrage

```bash
npm install
npm run dev
```

Ouvrir [http://localhost:3000](http://localhost:3000).

```bash
npm run build   # build de production
npm run start   # servir le build
npm run typecheck
npm run lint
```

## Fonctionnalités

### Parcours particulier (< 5 minutes)
Accueil → Revenus → Dépenses → Dettes → Résumé → Export

- Revenus (12 types suisses) et dépenses (15 catégories repliables), lignes
  illimitées, conversion automatique de toute fréquence en équivalent mensuel
- Suivi budget prévu / réel par ligne de dépense
- **Dettes & Engagements financiers** : section indépendante des dépenses
  (carte de crédit, crédit privé, leasing, prêt familial, dette fiscale,
  poursuite…), avec capital restant, mensualité, taux, statut
  (normal/retard/contentieux)
- Tableau de bord : revenus, dépenses, solde, reste à vivre, taux
  d'endettement (basé sur les mensualités de dettes réelles), taux
  d'épargne, poids fixe/variable
- **Score de santé financière** (0-100, Excellent/Bon/Fragile/Critique),
  calculé sur 6 facteurs pondérés et configurables
- **Analyse automatique (storytelling)** : le budget expliqué en phrases
  simples ("Votre logement représente X% de vos revenus…")
- **Budget Optimizer** : 3 scénarios (prudent / équilibré / ambitieux) avec
  prévisualisation immédiate de l'impact sur solde, endettement et score,
  applicables en un clic
- Alertes automatiques (vert / orange / rouge)
- Objectif d'épargne, foyer (reste à vivre par personne)
- Export PDF (jsPDF), Excel (.xlsx, entièrement modifiable, avec dettes),
  JSON (restaurable, validé par Zod à l'import)
- Sauvegarde automatique dans le navigateur

### Mode expert
- Panneau latéral invisible en mode particulier
- **Anomalies détectées automatiquement** (dépenses inhabituelles, cumul
  d'abonnements, endettement élevé, logement disproportionné, dettes en
  difficulté…), via l'Analysis Engine
- Commentaires, objectifs, recommandations, plan d'action
- **Historique horodaté** des points de suivi (rendez-vous) — archivage en
  un clic, consultable ensuite

### Préparé mais non actif dans ce MVP
- **Timeline financière** (`src/features/timeline/`) : composant et moteur
  de projection fonctionnels, non montés dans la navigation (activable en
  important `<Timeline />` dans `Dashboard.tsx`)
- **AI Engine** (`src/engines/ai/`) : interface `AIEngine` + implémentation
  `noopAIEngine` ; prête à recevoir une vraie implémentation (OpenAI,
  Claude…) sans modifier le reste de l'application

## Architecture

```
budget-plus/
├─ app/                       # layout.tsx, page.tsx (orchestre le parcours), globals.css
├─ src/
│  ├─ components/
│  │  ├─ ui/                  # Primitives (Button, Card, Input, Select, Textarea, Field)
│  │  └─ layout/               # Header, BottomNav
│  ├─ features/                # UI, organisée par domaine métier
│  │  ├─ accueil/              # Accueil.tsx, ParametresForm.tsx (RHF + Zod)
│  │  ├─ revenus/
│  │  ├─ depenses/
│  │  ├─ dettes/               # Dettes & Engagements financiers
│  │  ├─ dashboard/            # Résumé : score, storytelling, graphiques, stats
│  │  ├─ analyse-automatique/  # Storytelling (phrases)
│  │  ├─ budget-optimizer/     # Scénarios d'amélioration
│  │  ├─ foyer/, objectif-epargne/
│  │  ├─ expert/               # Panneau expert, anomalies, historique
│  │  ├─ timeline/             # Prêt, non monté (voir ci-dessus)
│  │  └─ export/
│  ├─ engines/                 # Business logic, indépendante de l'UI
│  │  ├─ analysis/             # Analysis Engine (déterministe, sans IA)
│  │  │   ├─ analysisEngine.ts   # Orchestrateur : score + ratios + anomalies + storytelling
│  │  │   ├─ scoreSante.ts
│  │  │   ├─ ratios.ts
│  │  │   ├─ anomalies.ts
│  │  │   ├─ storytelling.ts
│  │  │   └─ tauxEndettement.ts
│  │  ├─ optimizer/            # Budget Optimizer (scénarios, simulation)
│  │  ├─ timeline/             # Projection Engine (linéaire, MVP)
│  │  └─ ai/                   # AI Engine — interface + noopAIEngine (préparation)
│  ├─ context/BudgetContext.tsx  # État global, sauvegarde auto, calculs + analyse mémoïsés
│  ├─ hooks/
│  ├─ services/
│  │  ├─ calculations/budgetCalculator.ts  # Calculation Engine : totaux bruts
│  │  ├─ storage/               # Storage Engine (interface + localStorage)
│  │  └─ export/                # Export Engine (JSON, Excel, PDF)
│  ├─ config/referentielBudgetaire.ts  # Seuils configurables (aucun chiffre en dur ailleurs)
│  ├─ types/                    # budget, dette, analysis, ai, timeline
│  └─ utils/, lib/
```

### Séparation des responsabilités

- **Calculation Engine** (`services/calculations/`) : additions/conversions
  brutes (revenus, dépenses, dettes → `BudgetTotaux`). Ne connaît aucun seuil
  ni jugement de valeur.
- **Analysis Engine** (`engines/analysis/`) : transforme `BudgetTotaux` en
  jugements (score, anomalies, storytelling), à l'aide du référentiel. Reste
  100% déterministe.
- **AI Engine** (`engines/ai/`) : couche indépendante, reçoit le résultat de
  l'Analysis Engine et produira une synthèse en langage naturel. Aucune
  implémentation réelle pour l'instant (`noopAIEngine`).
- **UI** (`features/`, `components/`) : ne fait aucun calcul, consomme
  `totaux` / `analyse` / `alertes` depuis `useBudgetContext()`.

### Référentiel budgétaire configurable

`src/config/referentielBudgetaire.ts` centralise tous les seuils (reste à
vivre minimum, seuils d'endettement, poids logement max, pondérations du
score…). Pour adapter aux exigences d'un canton ou d'un organisme
partenaire : dupliquer `referentielSuisseParDefaut`, l'exposer, puis le
sélectionner dans `BudgetContext.tsx`. Aucun composant n'a besoin de changer.

### Couche de stockage remplaçable

`src/services/storage/storageService.interface.ts` définit le contrat
(`get`, `set`, `remove`). Le MVP l'implémente avec `localStorage`. Pour
passer à Supabase/Firebase/PostgreSQL : créer une implémentation respectant
`StorageService`, puis la substituer dans `BudgetContext.tsx`.

## Historique des évolutions (commits logiques)

1. `chore` — MVP initial (parcours, calculs, dashboard, export)
2. `refactor(calculator)` — extraction du taux d'endettement vers l'Analysis Engine
3. `feat(config)` — référentiel budgétaire externalisé
4. `feat(types)` — Dette + interfaces AnalysisEngine/AIEngine
5. `feat(dettes)` — section Dettes & Engagements (CRUD, exports, navigation)
6. `feat(analysis)` — ratios par catégorie, poids fixe/variable
7. `feat(dashboard)` — score de santé financière
8. `feat(storytelling)` — analyse automatique en langage naturel
9. `feat(anomalies)` — détection centralisée + panneau expert
10. `feat(optimizer)` — Budget Optimizer (3 scénarios)
11. `feat(expert)` — historique horodaté des points de suivi
12. `chore(timeline)` — structure de projection prête, désactivée par défaut

## Roadmap

**V2** — connexion utilisateur, historique multi-mois, synchronisation
cloud, comparaison des mois, activation de la Timeline.

**V3** — branchement d'un vrai AI Engine (OpenAI/Claude) sur les interfaces
déjà en place, recommandations personnalisées, détection d'anomalies
enrichie par IA, coaching budgétaire conversationnel.

## Déploiement

Projet 100% statique côté client (aucune route API requise) : compatible
Vercel, Netlify, ou tout hébergeur de site statique après `npm run build`.
