"use client";

import { useMemo, useState } from "react";
import { useBudgetContext } from "@/context/BudgetContext";
import { genererScenarios, type ResultatScenario } from "@/engines/optimizer/budgetOptimizer";
import { ScenarioCard } from "./ScenarioCard";

export function BudgetOptimizer() {
  const { budget, totaux, referentiel, remplacerBudget, aller } = useBudgetContext();
  const [applique, setApplique] = useState<string | null>(null);

  const scenarios = useMemo(
    () => genererScenarios(budget, totaux.solde, referentiel),
    [budget, totaux.solde, referentiel]
  );

  const appliquer = (scenario: ResultatScenario) => {
    remplacerBudget(scenario.budgetSimule);
    setApplique(scenario.nom);
  };

  return (
    <div className="flex flex-col gap-4 pb-10">
      <div>
        <h2 className="text-lg font-semibold text-slate-900">Budget Optimizer</h2>
        <p className="text-sm text-slate-500">
          Trois pistes d&apos;amélioration, du plus léger au plus structurant. Chaque scénario recalcule
          immédiatement le solde, le taux d&apos;endettement et le score de santé — rien n&apos;est appliqué tant
          que vous ne validez pas.
        </p>
      </div>

      {applique && (
        <div className="rounded-xl border border-emerald-200 bg-emerald-50 px-4 py-3 text-sm text-emerald-800">
          « {applique} » a été appliqué à votre budget. Consultez le résumé pour voir l&apos;impact complet, ou
          revenez ici pour explorer d&apos;autres pistes.
          <button onClick={() => aller("resume")} className="ml-2 font-medium underline">
            Voir le résumé
          </button>
        </div>
      )}

      <div className="grid grid-cols-1 gap-3 sm:grid-cols-3">
        {scenarios.map((s) => (
          <ScenarioCard key={s.id} scenario={s} onAppliquer={() => appliquer(s)} />
        ))}
      </div>

      <p className="text-center text-xs text-slate-400">
        Ces scénarios sont calculés par des règles déterministes. Une version future pourra proposer des
        scénarios personnalisés générés par IA, à partir de ces mêmes indicateurs.
      </p>
    </div>
  );
}
