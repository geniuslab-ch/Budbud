import { Sparkles, ArrowRight } from "lucide-react";
import { Card, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { formatCHF, formatPourcentage } from "@/utils/formatters";
import type { ResultatScenario } from "@/engines/optimizer/budgetOptimizer";

const STYLE_NIVEAU: Record<ResultatScenario["id"], string> = {
  prudent: "border-teal-200",
  equilibre: "border-amber-200",
  ambitieux: "border-rose-200",
};

interface Props {
  scenario: ResultatScenario;
  onAppliquer: () => void;
}

export function ScenarioCard({ scenario, onAppliquer }: Props) {
  return (
    <Card className={STYLE_NIVEAU[scenario.id]}>
      <div className="flex items-center gap-2">
        <Sparkles size={16} className="text-brand-700" />
        <CardTitle>{scenario.nom}</CardTitle>
      </div>
      <p className="mt-1 text-xs text-slate-500">{scenario.description}</p>

      <ul className="mt-3 flex flex-col gap-1 text-xs text-slate-600">
        {scenario.actions.map((a, i) => (
          <li key={i} className="flex items-start gap-1.5">
            <ArrowRight size={12} className="mt-0.5 shrink-0 text-slate-400" />
            {a.libelle}
          </li>
        ))}
      </ul>

      <div className="mt-4 rounded-xl bg-emerald-50 p-3">
        <p className="text-xs text-emerald-700">Gain mensuel estimé</p>
        <p className="text-xl font-semibold tabular-nums text-emerald-800">
          {scenario.gainMensuelCHF >= 0 ? "+" : ""}
          {formatCHF(scenario.gainMensuelCHF)}
        </p>
      </div>

      <dl className="mt-3 grid grid-cols-3 gap-2 text-center text-xs text-slate-600">
        <div>
          <dt className="text-slate-400">Solde</dt>
          <dd className="font-semibold tabular-nums">{formatCHF(scenario.soldeApres)}</dd>
        </div>
        <div>
          <dt className="text-slate-400">Endettement</dt>
          <dd className="font-semibold tabular-nums">{formatPourcentage(scenario.tauxEndettementApres)}</dd>
        </div>
        <div>
          <dt className="text-slate-400">Score santé</dt>
          <dd className="font-semibold tabular-nums">{scenario.scoreApres}/100</dd>
        </div>
      </dl>

      <Button variante="primary" taille="sm" className="mt-4 w-full" onClick={onAppliquer}>
        Appliquer ce scénario
      </Button>
    </Card>
  );
}
