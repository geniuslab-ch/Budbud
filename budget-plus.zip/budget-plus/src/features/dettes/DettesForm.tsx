"use client";

import { Plus, AlertTriangle } from "lucide-react";
import { useBudgetContext } from "@/context/BudgetContext";
import { nouvelleDette } from "@/hooks/useBudget";
import { uid } from "@/lib/utils";
import { formatCHF } from "@/utils/formatters";
import { LigneDette } from "./LigneDette";
import type { Dette } from "@/types/dette.types";

export function DettesForm() {
  const { budget, setBudget, totaux } = useBudgetContext();
  const dettes = budget.dettes;

  const update = (id: string, patch: Dette) =>
    setBudget((b) => ({ ...b, dettes: b.dettes.map((d) => (d.id === id ? patch : d)) }));
  const add = () => setBudget((b) => ({ ...b, dettes: [...b.dettes, nouvelleDette()] }));
  const duplicate = (d: Dette) => setBudget((b) => ({ ...b, dettes: [...b.dettes, { ...d, id: uid() }] }));
  const remove = (id: string) => setBudget((b) => ({ ...b, dettes: b.dettes.filter((d) => d.id !== id) }));

  const enDifficulte = dettes.filter((d) => d.statut !== "normal");

  return (
    <div className="flex flex-col gap-4 pb-24">
      <div>
        <h2 className="text-lg font-semibold text-slate-900">Dettes &amp; engagements financiers</h2>
        <p className="text-sm text-slate-500">
          Section indépendante des dépenses : cartes de crédit, crédits privés, leasing, prêts familiaux, dettes
          fiscales, poursuites… Les mensualités alimentent automatiquement le taux d&apos;endettement.
        </p>
      </div>

      {dettes.length === 0 && (
        <div className="rounded-xl border border-dashed border-slate-300 p-6 text-center text-sm text-slate-500">
          Aucune dette enregistrée. C&apos;est une bonne nouvelle — ou ajoutez-en une si nécessaire.
        </div>
      )}

      {enDifficulte.length > 0 && (
        <div className="flex items-center gap-2 rounded-xl border border-amber-200 bg-amber-50 px-4 py-3 text-sm text-amber-800">
          <AlertTriangle size={18} className="shrink-0" />
          {enDifficulte.length} dette{enDifficulte.length > 1 ? "s" : ""} en retard ou en contentieux à surveiller de près.
        </div>
      )}

      <div className="flex flex-col gap-3">
        {dettes.map((d) => (
          <LigneDette
            key={d.id} dette={d}
            onChange={(patch) => update(d.id, patch)}
            onDuplicate={() => duplicate(d)}
            onDelete={() => remove(d.id)}
          />
        ))}
      </div>

      <button
        onClick={add}
        className="flex items-center justify-center gap-2 rounded-xl border-2 border-dashed border-brand-300 py-3 text-sm font-medium text-brand-700 hover:bg-brand-50"
      >
        <Plus size={16} /> Ajouter une dette
      </button>

      <div className="sticky bottom-20 mt-2 grid grid-cols-2 gap-3 rounded-xl bg-slate-900 px-4 py-3 text-white shadow-lg sm:static sm:bottom-auto">
        <div>
          <p className="text-xs uppercase tracking-wide text-slate-300">Mensualités totales</p>
          <p className="text-xl font-semibold tabular-nums">{formatCHF(totaux.totalMensualitesDettes)}</p>
        </div>
        <div>
          <p className="text-xs uppercase tracking-wide text-slate-300">Capital restant dû</p>
          <p className="text-xl font-semibold tabular-nums">{formatCHF(totaux.totalCapitalRestantDettes)}</p>
        </div>
      </div>
    </div>
  );
}
