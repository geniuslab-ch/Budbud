"use client";

import { Copy, Trash2 } from "lucide-react";
import { Field } from "@/components/ui/field";
import { Input } from "@/components/ui/input";
import { Select } from "@/components/ui/select";
import type { Dette, StatutDette, TypeDette } from "@/types/dette.types";

const TYPES_DETTES: TypeDette[] = [
  "Carte de crédit",
  "Crédit privé",
  "Leasing",
  "Prêt familial",
  "Dette fiscale",
  "Poursuite",
  "Autre",
];

const STATUTS: { value: StatutDette; label: string; classe: string }[] = [
  { value: "normal", label: "Normal", classe: "text-emerald-700" },
  { value: "retard", label: "Retard", classe: "text-amber-700" },
  { value: "contentieux", label: "Contentieux", classe: "text-rose-700" },
];

interface Props {
  dette: Dette;
  onChange: (dette: Dette) => void;
  onDuplicate: () => void;
  onDelete: () => void;
}

export function LigneDette({ dette, onChange, onDuplicate, onDelete }: Props) {
  return (
    <div className="grid grid-cols-1 gap-2 rounded-xl border border-slate-200 bg-white p-3 sm:grid-cols-12 sm:items-end sm:gap-3">
      <Field label="Nom" className="sm:col-span-3">
        <Input value={dette.nom} onChange={(e) => onChange({ ...dette, nom: e.target.value })} placeholder="Ex : Leasing voiture" />
      </Field>
      <Field label="Créancier" className="sm:col-span-3">
        <Input value={dette.creancier} onChange={(e) => onChange({ ...dette, creancier: e.target.value })} placeholder="Ex : Banque X" />
      </Field>
      <Field label="Type" className="sm:col-span-3">
        <Select value={dette.type} onChange={(e) => onChange({ ...dette, type: e.target.value as TypeDette })}>
          {TYPES_DETTES.map((t) => (
            <option key={t} value={t}>{t}</option>
          ))}
        </Select>
      </Field>
      <Field label="Statut" className="sm:col-span-3">
        <Select value={dette.statut} onChange={(e) => onChange({ ...dette, statut: e.target.value as StatutDette })}>
          {STATUTS.map((s) => (
            <option key={s.value} value={s.value}>{s.label}</option>
          ))}
        </Select>
      </Field>

      <Field label="Capital restant (CHF)" className="sm:col-span-3">
        <Input
          type="number" min="0" value={dette.capitalRestant}
          onChange={(e) => onChange({ ...dette, capitalRestant: e.target.value === "" ? "" : Number(e.target.value) })}
        />
      </Field>
      <Field label="Mensualité (CHF)" className="sm:col-span-3">
        <Input
          type="number" min="0" value={dette.mensualite}
          onChange={(e) => onChange({ ...dette, mensualite: e.target.value === "" ? "" : Number(e.target.value) })}
        />
      </Field>
      <Field label="Taux d'intérêt (%, optionnel)" className="sm:col-span-3">
        <Input
          type="number" min="0" step="0.1" value={dette.tauxInteret ?? ""}
          onChange={(e) => onChange({ ...dette, tauxInteret: e.target.value === "" ? "" : Number(e.target.value) })}
        />
      </Field>
      <Field label="Date de fin (optionnelle)" className="sm:col-span-3">
        <Input type="date" value={dette.dateFin ?? ""} onChange={(e) => onChange({ ...dette, dateFin: e.target.value })} />
      </Field>

      <div className="flex items-center gap-2 sm:col-span-12 sm:justify-end">
        <span className={`mr-auto text-xs font-medium ${STATUTS.find((s) => s.value === dette.statut)?.classe}`}>
          {dette.statut === "normal" ? "" : `⚠ ${STATUTS.find((s) => s.value === dette.statut)?.label}`}
        </span>
        <button aria-label="Dupliquer" onClick={onDuplicate} className="rounded-lg border border-slate-200 p-2 text-slate-500 hover:bg-slate-50">
          <Copy size={16} />
        </button>
        <button aria-label="Supprimer" onClick={onDelete} className="rounded-lg border border-slate-200 p-2 text-rose-500 hover:bg-rose-50">
          <Trash2 size={16} />
        </button>
      </div>
      <Field label="Commentaire (optionnel)" className="sm:col-span-12">
        <Input value={dette.commentaire ?? ""} onChange={(e) => onChange({ ...dette, commentaire: e.target.value })} placeholder="Précision…" />
      </Field>
    </div>
  );
}
