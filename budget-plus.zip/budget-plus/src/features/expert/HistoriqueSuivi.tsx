import { History } from "lucide-react";
import type { EntreeSuiviExpert } from "@/types/budget.types";

function formaterDate(iso: string): string {
  try {
    return new Intl.DateTimeFormat("fr-CH", { dateStyle: "medium", timeStyle: "short" }).format(new Date(iso));
  } catch {
    return iso;
  }
}

/**
 * Historique horodaté des points de suivi précédents (rendez-vous). Prévu
 * pour accueillir plus tard plusieurs rendez-vous liés à un même bénéficiaire
 * suivi dans le temps, sans changement de structure.
 */
export function HistoriqueSuivi({ entrees }: { entrees: EntreeSuiviExpert[] }) {
  if (entrees.length === 0) {
    return <p className="text-xs text-slate-400">Aucun point de suivi archivé pour l&apos;instant.</p>;
  }

  return (
    <ul className="flex flex-col gap-2">
      {[...entrees].reverse().map((entree) => (
        <li key={entree.id} className="rounded-lg border border-slate-200 bg-slate-50 p-3 text-xs">
          <div className="mb-1 flex items-center gap-1.5 font-medium text-slate-700">
            <History size={12} /> {formaterDate(entree.date)}
          </div>
          {entree.commentaires && <p className="text-slate-600">{entree.commentaires}</p>}
          {entree.objectifs && <p className="mt-1 text-slate-500">Objectifs : {entree.objectifs}</p>}
          {entree.planAction && <p className="mt-1 text-slate-500">Plan d&apos;action : {entree.planAction}</p>}
        </li>
      ))}
    </ul>
  );
}
