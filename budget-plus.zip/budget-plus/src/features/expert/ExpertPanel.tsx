"use client";

import { Archive, MessageSquare, ShieldAlert, X } from "lucide-react";
import { Field } from "@/components/ui/field";
import { Textarea } from "@/components/ui/textarea";
import { Button } from "@/components/ui/button";
import { useBudgetContext } from "@/context/BudgetContext";
import { uid } from "@/lib/utils";
import { AnomaliesList } from "./AnomaliesList";
import { HistoriqueSuivi } from "./HistoriqueSuivi";
import type { NoteExpert } from "@/types/budget.types";

export function ExpertPanel() {
  const { budget, setBudget, analyse, panneauExpertOuvert, setPanneauExpertOuvert } = useBudgetContext();

  if (!panneauExpertOuvert) return null;

  const update = (champ: keyof Omit<NoteExpert, "historique">, valeur: string) =>
    setBudget((b) => ({ ...b, expertNotes: { ...b.expertNotes, [champ]: valeur } }));

  const archiverSuivi = () => {
    setBudget((b) => ({
      ...b,
      expertNotes: {
        commentaires: "",
        objectifs: "",
        recommandations: "",
        planAction: "",
        historique: [
          ...b.expertNotes.historique,
          {
            id: uid(),
            date: new Date().toISOString(),
            commentaires: b.expertNotes.commentaires,
            objectifs: b.expertNotes.objectifs,
            recommandations: b.expertNotes.recommandations,
            planAction: b.expertNotes.planAction,
          },
        ],
      },
    }));
  };

  return (
    <div
      className="fixed inset-0 z-40 flex justify-end bg-black/30"
      onClick={() => setPanneauExpertOuvert(false)}
    >
      <div
        className="flex h-full w-full max-w-sm flex-col gap-4 overflow-y-auto bg-white p-5 shadow-xl"
        onClick={(e) => e.stopPropagation()}
      >
        <div className="flex items-center justify-between">
          <div className="flex items-center gap-2">
            <MessageSquare size={18} className="text-brand-700" />
            <h3 className="font-semibold text-slate-900">Mode expert</h3>
          </div>
          <button
            onClick={() => setPanneauExpertOuvert(false)}
            aria-label="Fermer"
            className="rounded-lg p-1 text-slate-500 hover:bg-slate-100"
          >
            <X size={18} />
          </button>
        </div>
        <p className="text-xs text-slate-500">
          Ces notes sont réservées au professionnel et ne sont jamais visibles dans le mode particulier.
        </p>

        <div>
          <div className="mb-2 flex items-center gap-2">
            <ShieldAlert size={16} className="text-slate-500" />
            <h4 className="text-sm font-medium text-slate-800">
              Anomalies détectées {analyse.anomalies.length > 0 && `(${analyse.anomalies.length})`}
            </h4>
          </div>
          <AnomaliesList anomalies={analyse.anomalies} />
        </div>

        <div className="border-t border-slate-100 pt-4">
          <h4 className="mb-2 text-sm font-medium text-slate-800">Suivi actuel</h4>
        </div>

        <div className="border-t border-slate-100 pt-4">
          <h4 className="mb-2 text-sm font-medium text-slate-800">Suivi actuel</h4>
        </div>

        <Field label="Commentaires">
          <Textarea rows={3} value={budget.expertNotes.commentaires} onChange={(e) => update("commentaires", e.target.value)} />
        </Field>
        <Field label="Objectifs">
          <Textarea rows={3} value={budget.expertNotes.objectifs} onChange={(e) => update("objectifs", e.target.value)} />
        </Field>
        <Field label="Recommandations">
          <Textarea rows={3} value={budget.expertNotes.recommandations} onChange={(e) => update("recommandations", e.target.value)} />
        </Field>
        <Field label="Plan d'action">
          <Textarea rows={3} value={budget.expertNotes.planAction} onChange={(e) => update("planAction", e.target.value)} />
        </Field>

        <Button variante="secondary" taille="sm" onClick={archiverSuivi} className="self-start">
          <Archive size={14} /> Archiver ce point de suivi
        </Button>

        <div className="border-t border-slate-100 pt-4">
          <h4 className="mb-2 text-sm font-medium text-slate-800">
            Historique {budget.expertNotes.historique.length > 0 && `(${budget.expertNotes.historique.length})`}
          </h4>
          <HistoriqueSuivi entrees={budget.expertNotes.historique} />
        </div>
      </div>
    </div>
  );
}
