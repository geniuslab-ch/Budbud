import { ShieldAlert, Info, AlertTriangle } from "lucide-react";
import type { Anomalie } from "@/types/analysis.types";

const STYLE_NIVEAU: Record<Anomalie["niveau"], { icone: typeof Info; classe: string }> = {
  info: { icone: Info, classe: "border-slate-200 bg-slate-50 text-slate-700" },
  attention: { icone: AlertTriangle, classe: "border-amber-200 bg-amber-50 text-amber-800" },
  critique: { icone: ShieldAlert, classe: "border-rose-200 bg-rose-50 text-rose-800" },
};

/**
 * Liste des anomalies détectées par l'Analysis Engine — réservée au mode
 * expert : c'est une analyse volontairement plus technique, qui n'a pas sa
 * place dans le tableau de bord du particulier.
 */
export function AnomaliesList({ anomalies }: { anomalies: Anomalie[] }) {
  if (anomalies.length === 0) {
    return (
      <p className="rounded-lg border border-emerald-200 bg-emerald-50 px-3 py-2 text-xs text-emerald-800">
        Aucune anomalie détectée par l&apos;Analysis Engine.
      </p>
    );
  }

  return (
    <ul className="flex flex-col gap-2">
      {anomalies.map((a, i) => {
        const style = STYLE_NIVEAU[a.niveau];
        const Icone = style.icone;
        return (
          <li key={i} className={`flex items-start gap-2 rounded-lg border px-3 py-2 text-xs ${style.classe}`}>
            <Icone size={14} className="mt-0.5 shrink-0" />
            <div>
              <p className="font-medium">{a.titre}</p>
              <p className="mt-0.5 opacity-90">{a.detail}</p>
            </div>
          </li>
        );
      })}
    </ul>
  );
}
