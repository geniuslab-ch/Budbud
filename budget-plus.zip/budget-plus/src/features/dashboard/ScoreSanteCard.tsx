import { HeartPulse } from "lucide-react";
import { Card, CardTitle } from "@/components/ui/card";
import type { ScoreSante } from "@/types/analysis.types";

const STYLE_NIVEAU: Record<ScoreSante["niveau"], { texte: string; barre: string; fond: string }> = {
  Excellent: { texte: "text-emerald-700", barre: "bg-emerald-600", fond: "bg-emerald-50" },
  Bon: { texte: "text-teal-700", barre: "bg-teal-600", fond: "bg-teal-50" },
  Fragile: { texte: "text-amber-700", barre: "bg-amber-500", fond: "bg-amber-50" },
  Critique: { texte: "text-rose-700", barre: "bg-rose-600", fond: "bg-rose-50" },
};

export function ScoreSanteCard({ score }: { score: ScoreSante }) {
  const style = STYLE_NIVEAU[score.niveau];

  return (
    <Card className={style.fond}>
      <div className="flex items-center gap-2">
        <HeartPulse size={18} className={style.texte} />
        <CardTitle>Santé financière</CardTitle>
      </div>

      <div className="mt-2 flex items-end gap-3">
        <span className={`text-4xl font-bold tabular-nums ${style.texte}`}>{score.valeur}</span>
        <span className="mb-1 text-sm text-slate-500">/ 100</span>
        <span className={`mb-1.5 ml-auto rounded-full px-3 py-1 text-xs font-semibold ${style.texte} bg-white`}>
          {score.niveau}
        </span>
      </div>

      <div className="mt-2 h-2 w-full overflow-hidden rounded-full bg-white">
        <div className={`h-full ${style.barre}`} style={{ width: `${score.valeur}%` }} />
      </div>

      <details className="mt-3 text-xs text-slate-600">
        <summary className="cursor-pointer select-none font-medium text-slate-700">Détail du calcul</summary>
        <ul className="mt-2 flex flex-col gap-1">
          {score.detail.map((s) => (
            <li key={s.cle} className="flex items-center justify-between">
              <span>{s.label}</span>
              <span className="tabular-nums text-slate-500">{Math.round(s.valeur)}/100 · pondération {s.poids}%</span>
            </li>
          ))}
        </ul>
      </details>
    </Card>
  );
}
