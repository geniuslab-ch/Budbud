import { Card, CardTitle } from "@/components/ui/card";
import { formatCHF, formatPourcentage } from "@/utils/formatters";

interface Props {
  label: string;
  montant: number;
  pourcentageDuRevenu: number;
  tonalite: "fixe" | "variable";
}

const styles = {
  fixe: { barre: "bg-slate-700", fond: "bg-slate-100" },
  variable: { barre: "bg-brand-500", fond: "bg-brand-50" },
} as const;

export function FixeVariableCard({ label, montant, pourcentageDuRevenu, tonalite }: Props) {
  const style = styles[tonalite];
  return (
    <Card>
      <CardTitle>{label}</CardTitle>
      <p className="mt-1 text-2xl font-semibold tabular-nums text-slate-900">{formatCHF(montant)}</p>
      <p className="text-xs text-slate-500">{formatPourcentage(pourcentageDuRevenu)} du revenu</p>
      <div className={`mt-3 h-2 w-full overflow-hidden rounded-full ${style.fond}`}>
        <div
          className={`h-full ${style.barre}`}
          style={{ width: `${Math.min(100, pourcentageDuRevenu)}%` }}
        />
      </div>
    </Card>
  );
}
