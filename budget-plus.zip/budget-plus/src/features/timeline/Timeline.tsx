"use client";

import { Landmark, PiggyBank, TrendingDown } from "lucide-react";
import { Card, CardTitle } from "@/components/ui/card";
import { formatCHF } from "@/utils/formatters";
import type { ProjectionFinanciere } from "@/types/timeline.types";

/**
 * Composant Timeline financière — Aujourd'hui → fin du mois → 3/6/12 mois.
 * Fonctionnel mais volontairement non monté dans app/page.tsx ni dans la
 * navigation pour le MVP (voir README, section "Fonctionnalités désactivées
 * par défaut"). Pour l'activer : importer <Timeline /> dans Dashboard.tsx
 * ou lui dédier une étape du parcours, une fois le besoin confirmé.
 */
export function Timeline({ projection }: { projection: ProjectionFinanciere }) {
  return (
    <Card>
      <CardTitle>Timeline financière</CardTitle>
      <p className="mt-1 text-xs text-slate-500">{projection.hypothese}</p>

      <div className="mt-4 flex flex-col gap-3">
        {projection.points.map((p, i) => (
          <div key={p.horizon} className="flex items-center gap-3">
            <div className="flex flex-col items-center">
              <div className="h-2.5 w-2.5 rounded-full bg-brand-600" />
              {i < projection.points.length - 1 && <div className="h-10 w-px bg-slate-200" />}
            </div>
            <div className="flex-1 pb-2">
              <p className="text-sm font-medium text-slate-800">{p.label}</p>
              <div className="mt-1 flex flex-wrap gap-3 text-xs text-slate-500">
                <span className="flex items-center gap-1">
                  <Landmark size={12} /> Solde cumulé : {formatCHF(p.soldeCumule)}
                </span>
                <span className="flex items-center gap-1">
                  <PiggyBank size={12} /> Épargne : {formatCHF(p.epargneCumulee)}
                </span>
                <span className="flex items-center gap-1">
                  <TrendingDown size={12} /> Dettes restantes : {formatCHF(p.capitalRestantDettes)}
                </span>
              </div>
            </div>
          </div>
        ))}
      </div>
    </Card>
  );
}
