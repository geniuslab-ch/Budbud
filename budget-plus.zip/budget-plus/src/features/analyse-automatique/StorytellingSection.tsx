import { Sparkles, TrendingUp, TrendingDown, Minus } from "lucide-react";
import { Card, CardTitle } from "@/components/ui/card";
import type { PhraseStorytelling } from "@/types/analysis.types";

const ICONE: Record<PhraseStorytelling["tonalite"], typeof TrendingUp> = {
  positif: TrendingUp,
  negatif: TrendingDown,
  neutre: Minus,
};

const COULEUR: Record<PhraseStorytelling["tonalite"], string> = {
  positif: "text-emerald-600",
  negatif: "text-rose-600",
  neutre: "text-slate-400",
};

export function StorytellingSection({ phrases }: { phrases: PhraseStorytelling[] }) {
  if (phrases.length === 0) return null;

  return (
    <Card>
      <div className="mb-2 flex items-center gap-2">
        <Sparkles size={18} className="text-brand-700" />
        <CardTitle>Ce que raconte votre budget</CardTitle>
      </div>
      <ul className="flex flex-col gap-2">
        {phrases.map((p) => {
          const Icone = ICONE[p.tonalite];
          return (
            <li key={p.id} className="flex items-start gap-2 text-sm text-slate-700">
              <Icone size={16} className={`mt-0.5 shrink-0 ${COULEUR[p.tonalite]}`} />
              <span>{p.texte}</span>
            </li>
          );
        })}
      </ul>
    </Card>
  );
}
