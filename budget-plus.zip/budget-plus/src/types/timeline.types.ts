export type HorizonProjection = "aujourdhui" | "fin_mois" | "3_mois" | "6_mois" | "12_mois";

export interface PointProjection {
  horizon: HorizonProjection;
  label: string;
  dateEstimee: string; // ISO
  soldeCumule: number;
  epargneCumulee: number;
  capitalRestantDettes: number;
}

/**
 * Projection financière dans le temps. Structure prête pour la Timeline
 * (voir features/timeline) ; désactivée par défaut dans le MVP (voir
 * TIMELINE_ACTIVE dans référentielBudgétaire ou constants).
 */
export interface ProjectionFinanciere {
  points: PointProjection[];
  hypothese: string;
}
