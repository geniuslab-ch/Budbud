import type { Budget, BudgetTotaux } from "./budget.types";
import type { AnalyseFinanciere } from "./analysis.types";

export interface AIRecommandation {
  id: string;
  titre: string;
  description: string;
  gainEstimeCHF?: number;
  priorite: "haute" | "moyenne" | "basse";
}

export interface AISynthese {
  resume: string;
  pointsForts: string[];
  pointsAttention: string[];
  recommandations: AIRecommandation[];
  /** Nom du modèle ayant généré la synthèse ("noop" pour l'implémentation MVP). */
  genereePar: string;
}

/**
 * Contrat que devra respecter tout moteur d'IA (OpenAI, Claude, ou autre)
 * branché sur BudBud. Il reçoit uniquement les données déjà calculées par
 * l'Analysis Engine — jamais de logique métier côté IA — et produit une
 * synthèse en langage naturel. Aucune implémentation réelle n'existe encore
 * (voir engines/ai/noopAIEngine.ts) : cette interface prépare le terrain.
 */
export interface AIEngine {
  readonly nom: string;
  genererSynthese(budget: Budget, totaux: BudgetTotaux, analyse: AnalyseFinanciere): Promise<AISynthese>;
}
