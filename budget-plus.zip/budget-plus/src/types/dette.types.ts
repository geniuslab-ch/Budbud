export type TypeDette =
  | "Carte de crédit"
  | "Crédit privé"
  | "Leasing"
  | "Prêt familial"
  | "Dette fiscale"
  | "Poursuite"
  | "Autre";

export type StatutDette = "normal" | "retard" | "contentieux";

export interface Dette {
  id: string;
  nom: string;
  creancier: string;
  type: TypeDette;
  capitalRestant: number | "";
  mensualite: number | "";
  tauxInteret?: number | "";
  dateFin?: string;
  statut: StatutDette;
  commentaire?: string;
}
