import type { Dette } from "./dette.types";

export type Frequence =
  | "hebdomadaire"
  | "mensuel"
  | "trimestriel"
  | "semestriel"
  | "annuel"
  | "unique";

export type TypeRevenu =
  | "Salaire"
  | "Salaire conjoint"
  | "Chômage"
  | "AVS"
  | "AI"
  | "Prestations complémentaires"
  | "Pension"
  | "Allocations"
  | "Rentes"
  | "Revenus indépendants"
  | "Revenus locatifs"
  | "Autre";

export type CategorieDepense =
  | "Logement"
  | "Assurances"
  | "Transport"
  | "Nourriture"
  | "Santé"
  | "Enfants"
  | "Télécommunications"
  | "Impôts"
  | "Crédits"
  | "Loisirs"
  | "Abonnements"
  | "Animaux"
  | "Vêtements"
  | "Divers"
  | "Dépenses exceptionnelles";

export interface LigneBudget {
  id: string;
  nom: string;
  montant: number | "";
  frequence: Frequence;
  commentaire?: string;
}

export type LigneRevenu = LigneBudget;

export interface LigneDepense extends LigneBudget {
  budgetReel?: number | "";
}

export type DepensesParCategorie = Record<CategorieDepense, LigneDepense[]>;

export interface Foyer {
  adultes: number | "";
  enfants: number | "";
}

export interface EntreeSuiviExpert {
  id: string;
  date: string; // ISO
  commentaires: string;
  objectifs: string;
  recommandations: string;
  planAction: string;
}

export interface NoteExpert {
  commentaires: string;
  objectifs: string;
  recommandations: string;
  planAction: string;
  /** Historique horodaté des points de suivi précédents (rendez-vous). */
  historique: EntreeSuiviExpert[];
}

export interface Budget {
  nom: string;
  revenus: LigneRevenu[];
  depenses: DepensesParCategorie;
  /** Section indépendante des dépenses — voir dette.types.ts. */
  dettes: Dette[];
  foyer: Foyer;
  objectifEpargne: number | "";
  expertNotes: NoteExpert;
}

export interface BudgetTotaux {
  totalRevenus: number;
  totalDepensesPrevu: number;
  totalDepensesReel: number;
  ecartTotal: number;
  /** Mensualités cumulées de la section Dettes & Engagements. */
  totalMensualitesDettes: number;
  /** Capital restant dû, toutes dettes confondues. */
  totalCapitalRestantDettes: number;
  /** Dépenses + mensualités de dettes : la vraie charge mensuelle. */
  totalDepensesEtDettes: number;
  solde: number;
  resteAVivre: number;
  resteAVivreParPersonne: number;
  tauxEndettement: number;
  tauxEpargne: number;
  depensesFixes: number;
  depensesVariables: number;
  /** @deprecated informatif — conservé pour compat., remplacé par totalMensualitesDettes dans le calcul du taux d'endettement. */
  totalCredits: number;
  parCategorie: Record<CategorieDepense, number>;
}

export type NiveauAlerte = "rouge" | "orange";

export interface Alerte {
  niveau: NiveauAlerte;
  texte: string;
}

export type EtapeParcours =
  | "accueil"
  | "revenus"
  | "depenses"
  | "dettes"
  | "resume"
  | "optimizer"
  | "export";
