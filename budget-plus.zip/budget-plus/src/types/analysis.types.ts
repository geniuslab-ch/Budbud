import type { CategorieDepense } from "./budget.types";

export type NiveauSante = "Excellent" | "Bon" | "Fragile" | "Critique";

export interface SousScore {
  cle: "endettement" | "resteAVivre" | "epargne" | "chargesFixes" | "logement" | "stabiliteRevenus";
  label: string;
  valeur: number; // 0-100
  poids: number; // %
}

export interface ScoreSante {
  valeur: number; // 0-100
  niveau: NiveauSante;
  detail: SousScore[];
}

export interface RatioCategorie {
  categorie: CategorieDepense;
  montant: number;
  pourcentageDuRevenu: number;
  pourcentageDesDepenses: number;
}

export type TypeAnomalie =
  | "depense_inhabituelle"
  | "abonnements_multiples"
  | "dettes_importantes"
  | "reste_a_vivre_insuffisant"
  | "endettement_eleve"
  | "logement_disproportionne"
  | "absence_epargne"
  | "dette_en_difficulte";

export type NiveauAnomalie = "info" | "attention" | "critique";

export interface Anomalie {
  type: TypeAnomalie;
  niveau: NiveauAnomalie;
  titre: string;
  detail: string;
}

export interface PhraseStorytelling {
  id: string;
  texte: string;
  tonalite: "neutre" | "positif" | "negatif";
}

/**
 * Résultat produit par l'Analysis Engine : uniquement des calculs
 * déterministes (aucune IA). C'est cet objet que l'AI Engine (Phase 3)
 * recevra en entrée pour générer synthèse et recommandations en langage
 * naturel.
 */
export interface AnalyseFinanciere {
  score: ScoreSante;
  ratiosParCategorie: RatioCategorie[];
  poidsDepensesFixes: number; // % du revenu
  poidsDepensesVariables: number; // % du revenu
  poidsLogement: number; // % du revenu
  anomalies: Anomalie[];
  storytelling: PhraseStorytelling[];
}
