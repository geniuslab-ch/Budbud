import type { BudgetTotaux } from "@/types/budget.types";
import type { HorizonProjection, PointProjection, ProjectionFinanciere } from "@/types/timeline.types";

const HORIZONS: { horizon: HorizonProjection; label: string; mois: number }[] = [
  { horizon: "aujourdhui", label: "Aujourd'hui", mois: 0 },
  { horizon: "fin_mois", label: "Fin du mois", mois: 1 },
  { horizon: "3_mois", label: "Dans 3 mois", mois: 3 },
  { horizon: "6_mois", label: "Dans 6 mois", mois: 6 },
  { horizon: "12_mois", label: "Dans 12 mois", mois: 12 },
];

/**
 * Projection linéaire simple : suppose un solde mensuel constant et un
 * remboursement de dettes régulier. Volontairement naïve pour le MVP —
 * suffisante pour visualiser une tendance, pas une prévision actuarielle.
 * Peut être désactivée dans l'UI (voir features/timeline) sans supprimer
 * le moteur : l'architecture reste prête pour une V2 plus fine (taux
 * variables, événements ponctuels, saisonnalité...).
 */
export function calculerProjection(totaux: BudgetTotaux): ProjectionFinanciere {
  const aujourdhui = new Date();

  const points: PointProjection[] = HORIZONS.map(({ horizon, label, mois }) => {
    const date = new Date(aujourdhui);
    date.setMonth(date.getMonth() + mois);

    const mensualiteDette = totaux.totalMensualitesDettes;
    const capitalRestant = Math.max(0, totaux.totalCapitalRestantDettes - mensualiteDette * mois);

    return {
      horizon,
      label,
      dateEstimee: date.toISOString(),
      soldeCumule: Math.round(totaux.solde * mois),
      epargneCumulee: Math.round(Math.max(0, totaux.solde) * mois),
      capitalRestantDettes: Math.round(capitalRestant),
    };
  });

  return {
    points,
    hypothese: "Projection linéaire à solde mensuel constant — ne tient pas compte des variations saisonnières ou événements ponctuels.",
  };
}
