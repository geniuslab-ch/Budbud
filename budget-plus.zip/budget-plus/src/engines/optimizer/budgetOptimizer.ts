import type { Budget, CategorieDepense } from "@/types/budget.types";
import { versNombre } from "@/utils/formatters";
import { calculerTotaux } from "@/services/calculations/budgetCalculator";
import { analyserBudget } from "@/engines/analysis/analysisEngine";
import type { ReferentielBudgetaire } from "@/config/referentielBudgetaire";

export type NiveauScenario = "prudent" | "equilibre" | "ambitieux";

export interface ActionScenario {
  libelle: string;
  /** Réduit toutes les lignes d'une catégorie de dépenses d'un pourcentage donné. */
  reductionCategorie?: { categorie: CategorieDepense; pourcentage: number };
  /** Réduit les mensualités de dettes d'un pourcentage donné (ex. regroupement de crédits). */
  reductionMensualitesDettes?: { pourcentage: number };
}

export interface DefinitionScenario {
  id: NiveauScenario;
  nom: string;
  description: string;
  actions: ActionScenario[];
}

export interface ResultatScenario extends DefinitionScenario {
  budgetSimule: Budget;
  gainMensuelCHF: number;
  soldeApres: number;
  resteAVivreApresParPersonne: number;
  tauxEndettementApres: number;
  scoreApres: number;
}

/**
 * Applique une réduction en pourcentage à toutes les lignes "réel" (ou
 * "prévu" si aucun réel n'est saisi) d'une catégorie de dépenses.
 */
function appliquerReductionCategorie(budget: Budget, categorie: CategorieDepense, pourcentage: number): Budget {
  const facteur = 1 - pourcentage / 100;
  return {
    ...budget,
    depenses: {
      ...budget.depenses,
      [categorie]: (budget.depenses[categorie] ?? []).map((ligne) => {
        const base = ligne.budgetReel !== undefined && ligne.budgetReel !== "" ? ligne.budgetReel : ligne.montant;
        const nouveau = Math.max(0, Math.round(versNombre(base) * facteur));
        return { ...ligne, budgetReel: nouveau };
      }),
    },
  };
}

/** Réduit toutes les mensualités de dettes d'un pourcentage (ex. regroupement de crédits). */
function appliquerReductionDettes(budget: Budget, pourcentage: number): Budget {
  const facteur = 1 - pourcentage / 100;
  return {
    ...budget,
    dettes: budget.dettes.map((d) => ({
      ...d,
      mensualite: Math.max(0, Math.round(versNombre(d.mensualite) * facteur)),
    })),
  };
}

function appliquerAction(budget: Budget, action: ActionScenario): Budget {
  let resultat = budget;
  if (action.reductionCategorie) {
    resultat = appliquerReductionCategorie(resultat, action.reductionCategorie.categorie, action.reductionCategorie.pourcentage);
  }
  if (action.reductionMensualitesDettes) {
    resultat = appliquerReductionDettes(resultat, action.reductionMensualitesDettes.pourcentage);
  }
  return resultat;
}

/** Applique toutes les actions d'un scénario sur une copie du budget (aucune mutation de l'original). */
export function appliquerScenario(budget: Budget, scenario: DefinitionScenario): Budget {
  return scenario.actions.reduce((b, action) => appliquerAction(b, action), budget);
}

export const SCENARIOS: DefinitionScenario[] = [
  {
    id: "prudent",
    nom: "Scénario prudent",
    description: "Petits ajustements sans impact sur le mode de vie.",
    actions: [
      { libelle: "Réduire les abonnements de 30%", reductionCategorie: { categorie: "Abonnements", pourcentage: 30 } },
      { libelle: "Réduire les loisirs de 15%", reductionCategorie: { categorie: "Loisirs", pourcentage: 15 } },
    ],
  },
  {
    id: "equilibre",
    nom: "Scénario équilibré",
    description: "Renégociation de contrats et réduction de postes secondaires.",
    actions: [
      { libelle: "Renégocier les assurances (-10%)", reductionCategorie: { categorie: "Assurances", pourcentage: 10 } },
      { libelle: "Réduire les dépenses diverses de 20%", reductionCategorie: { categorie: "Divers", pourcentage: 20 } },
      { libelle: "Réduire les abonnements de 50%", reductionCategorie: { categorie: "Abonnements", pourcentage: 50 } },
    ],
  },
  {
    id: "ambitieux",
    nom: "Scénario ambitieux",
    description: "Changements structurels : déménagement et regroupement de crédits.",
    actions: [
      { libelle: "Déménagement — logement -20%", reductionCategorie: { categorie: "Logement", pourcentage: 20 } },
      { libelle: "Regroupement de crédits (-15% de mensualités)", reductionMensualitesDettes: { pourcentage: 15 } },
      { libelle: "Réduire le transport de 10%", reductionCategorie: { categorie: "Transport", pourcentage: 10 } },
    ],
  },
];

/**
 * Génère les 3 scénarios prédéfinis appliqués à une copie du budget actuel,
 * avec le gain mensuel estimé et les indicateurs recalculés (solde, reste à
 * vivre, taux d'endettement, score de santé). Rien n'est persisté tant que
 * l'utilisateur n'a pas explicitement choisi d'appliquer un scénario.
 *
 * Le moteur est volontairement conçu pour accueillir plus tard des scénarios
 * générés par l'AI Engine, avec la même forme de sortie (ResultatScenario).
 */
export function genererScenarios(
  budget: Budget,
  soldeActuel: number,
  referentiel: ReferentielBudgetaire
): ResultatScenario[] {
  return SCENARIOS.map((scenario) => {
    const budgetSimule = appliquerScenario(budget, scenario);
    const totauxSimules = calculerTotaux(budgetSimule);
    const analyseSimulee = analyserBudget(budgetSimule, totauxSimules, referentiel);

    return {
      ...scenario,
      budgetSimule,
      gainMensuelCHF: totauxSimules.solde - soldeActuel,
      soldeApres: totauxSimules.solde,
      resteAVivreApresParPersonne: totauxSimules.resteAVivreParPersonne,
      tauxEndettementApres: totauxSimules.tauxEndettement,
      scoreApres: analyseSimulee.score.valeur,
    };
  });
}
