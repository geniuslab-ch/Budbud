import type { AIEngine, AISynthese } from "@/types/ai.types";
import type { Budget, BudgetTotaux } from "@/types/budget.types";
import type { AnalyseFinanciere } from "@/types/analysis.types";

/**
 * Implémentation "vide" de l'AIEngine : ne génère aucune synthèse en
 * langage naturel, se contente de refléter le storytelling déterministe
 * déjà produit par l'Analysis Engine. Sert de valeur par défaut tant
 * qu'aucun vrai moteur (OpenAI, Claude…) n'est branché — l'app reste
 * fonctionnelle et rien ne dépend d'une clé API absente.
 *
 * Pour brancher un vrai moteur : créer ex. `openAiEngine.ts` implémentant
 * `AIEngine`, puis le fournir à la place de `noopAIEngine` (voir
 * BudgetContext) — aucun composant UI n'a besoin de changer.
 */
export const noopAIEngine: AIEngine = {
  nom: "noop",
  async genererSynthese(_budget: Budget, _totaux: BudgetTotaux, analyse: AnalyseFinanciere): Promise<AISynthese> {
    return {
      resume: analyse.storytelling.map((p) => p.texte).join(" "),
      pointsForts: analyse.storytelling.filter((p) => p.tonalite === "positif").map((p) => p.texte),
      pointsAttention: analyse.storytelling.filter((p) => p.tonalite === "negatif").map((p) => p.texte),
      recommandations: [],
      genereePar: "noop",
    };
  },
};
