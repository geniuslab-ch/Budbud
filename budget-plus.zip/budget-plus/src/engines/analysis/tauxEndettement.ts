import type { BudgetTotaux } from "@/types/budget.types";

/**
 * Calcule le taux d'endettement (%) à partir des totaux du budget.
 * Isolé dans l'Analysis Engine pour pouvoir faire évoluer la définition
 * (aujourd'hui : catégorie "Crédits" des dépenses ; à terme : mensualités
 * de la section Dettes & Engagements, voir services/calculations une fois
 * la Phase 1 en place) sans toucher au calculateur de budget ni à l'UI.
 */
export function calculerTauxEndettement(totalRevenus: number, totalCredits: number): number {
  return totalRevenus > 0 ? (totalCredits / totalRevenus) * 100 : 0;
}
