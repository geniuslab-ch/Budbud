import type { BudgetTotaux, CategorieDepense } from "@/types/budget.types";
import type { RatioCategorie } from "@/types/analysis.types";
import { CATEGORIES_DEPENSES } from "@/utils/constants";

/** Calcule, pour chaque catégorie de dépense, son poids dans le revenu et dans le total des dépenses. */
export function calculerRatiosParCategorie(totaux: BudgetTotaux): RatioCategorie[] {
  return CATEGORIES_DEPENSES.map((categorie: CategorieDepense) => {
    const montant = totaux.parCategorie[categorie] ?? 0;
    return {
      categorie,
      montant,
      pourcentageDuRevenu: totaux.totalRevenus > 0 ? (montant / totaux.totalRevenus) * 100 : 0,
      pourcentageDesDepenses: totaux.totalDepensesReel > 0 ? (montant / totaux.totalDepensesReel) * 100 : 0,
    };
  }).filter((r) => r.montant > 0);
}

/** Poids du logement dans le revenu (%) — indicateur clé du score de santé et du storytelling. */
export function calculerPoidsLogement(totaux: BudgetTotaux): number {
  const logement = totaux.parCategorie["Logement"] ?? 0;
  return totaux.totalRevenus > 0 ? (logement / totaux.totalRevenus) * 100 : 0;
}

/** Poids des dépenses fixes / variables dans le revenu (%). */
export function calculerPoidsFixesVariables(totaux: BudgetTotaux): { fixes: number; variables: number } {
  return {
    fixes: totaux.totalRevenus > 0 ? (totaux.depensesFixes / totaux.totalRevenus) * 100 : 0,
    variables: totaux.totalRevenus > 0 ? (totaux.depensesVariables / totaux.totalRevenus) * 100 : 0,
  };
}
