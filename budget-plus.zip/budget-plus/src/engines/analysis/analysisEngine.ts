import type { Budget, BudgetTotaux } from "@/types/budget.types";
import type { AnalyseFinanciere } from "@/types/analysis.types";
import type { ReferentielBudgetaire } from "@/config/referentielBudgetaire";
import { calculerScoreSante } from "./scoreSante";
import { calculerPoidsFixesVariables, calculerPoidsLogement, calculerRatiosParCategorie } from "./ratios";
import { detecterAnomalies } from "./anomalies";
import { genererStorytelling } from "./storytelling";

/**
 * Point d'entrée unique de l'Analysis Engine : combine score de santé,
 * ratios par catégorie, détection d'anomalies et storytelling en un seul
 * objet `AnalyseFinanciere`, entièrement déterministe (aucune IA). C'est cet
 * objet que l'AI Engine consommera pour générer sa synthèse en langage
 * naturel (voir engines/ai/).
 */
export function analyserBudget(
  budget: Budget,
  totaux: BudgetTotaux,
  referentiel: ReferentielBudgetaire
): AnalyseFinanciere {
  const score = calculerScoreSante(budget, totaux, referentiel);
  const ratiosParCategorie = calculerRatiosParCategorie(totaux);
  const { fixes: poidsDepensesFixes, variables: poidsDepensesVariables } = calculerPoidsFixesVariables(totaux);
  const poidsLogement = calculerPoidsLogement(totaux);
  const anomalies = detecterAnomalies(budget, totaux, referentiel);
  const storytelling = genererStorytelling(budget, totaux, { poidsLogement, poidsDepensesFixes });

  return {
    score,
    ratiosParCategorie,
    poidsDepensesFixes,
    poidsDepensesVariables,
    poidsLogement,
    anomalies,
    storytelling,
  };
}
