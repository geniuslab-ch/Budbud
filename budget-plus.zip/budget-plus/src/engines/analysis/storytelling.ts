import type { Budget, BudgetTotaux } from "@/types/budget.types";
import type { PhraseStorytelling } from "@/types/analysis.types";

interface ContexteStorytelling {
  poidsLogement: number;
  poidsDepensesFixes: number;
}

/**
 * Traduit les indicateurs déjà calculés en phrases simples et lisibles par
 * un non-spécialiste. Purement déterministe (templating conditionnel) :
 * c'est la version "sans IA" du storytelling. L'AI Engine (Phase 3) pourra
 * plus tard reformuler ou enrichir ces phrases, sans changer leur source.
 */
export function genererStorytelling(
  budget: Budget,
  totaux: BudgetTotaux,
  { poidsLogement, poidsDepensesFixes }: ContexteStorytelling
): PhraseStorytelling[] {
  const phrases: PhraseStorytelling[] = [];
  let i = 0;
  const ajouter = (texte: string, tonalite: PhraseStorytelling["tonalite"]) =>
    phrases.push({ id: `story-${i++}`, texte, tonalite });

  if (totaux.totalRevenus === 0) {
    ajouter("Ajoutez vos revenus pour démarrer l'analyse de votre budget.", "neutre");
    return phrases;
  }

  if (poidsLogement > 0) {
    ajouter(
      `Votre logement représente ${Math.round(poidsLogement)}% de vos revenus.`,
      poidsLogement > 33 ? "negatif" : "neutre"
    );
  }

  ajouter(
    `Vos dépenses fixes absorbent ${Math.round(poidsDepensesFixes)}% de vos revenus.`,
    poidsDepensesFixes > 60 ? "negatif" : "neutre"
  );

  if (totaux.totalMensualitesDettes > 0) {
    ajouter(
      `Vos dettes vous coûtent ${Math.round(totaux.totalMensualitesDettes)} CHF par mois, soit ${Math.round(totaux.tauxEndettement)}% de vos revenus.`,
      totaux.tauxEndettement > 33 ? "negatif" : "neutre"
    );
  }

  if (totaux.solde < 0) {
    ajouter("Votre budget présente un déficit : les charges dépassent les revenus.", "negatif");
  } else if (totaux.resteAVivreParPersonne < 600) {
    ajouter("Votre reste à vivre est faible une fois toutes les charges payées.", "negatif");
  } else {
    ajouter("Votre reste à vivre permet de couvrir les dépenses courantes.", "positif");
  }

  if (totaux.tauxEpargne >= 10) {
    ajouter(`Vous parvenez à épargner ${Math.round(totaux.tauxEpargne)}% de vos revenus chaque mois — une bonne base.`, "positif");
  } else if (totaux.solde > 0) {
    ajouter("Une petite marge existe mais aucune épargne régulière n'est encore mise de côté.", "neutre");
  }

  const dettesEnDifficulte = budget.dettes.filter((d) => d.statut !== "normal");
  if (dettesEnDifficulte.length > 0) {
    ajouter(
      `${dettesEnDifficulte.length} dette${dettesEnDifficulte.length > 1 ? "s sont" : " est"} en retard ou en contentieux — une attention particulière est recommandée.`,
      "negatif"
    );
  }

  return phrases;
}
