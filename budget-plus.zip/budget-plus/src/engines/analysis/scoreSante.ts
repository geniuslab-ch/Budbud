import type { BudgetTotaux } from "@/types/budget.types";
import type { NiveauSante, ScoreSante, SousScore } from "@/types/analysis.types";
import type { ReferentielBudgetaire } from "@/config/referentielBudgetaire";
import type { Budget } from "@/types/budget.types";
import { versNombre } from "@/utils/formatters";
import { calculerPoidsFixesVariables, calculerPoidsLogement } from "./ratios";

const REVENUS_STABLES = new Set([
  "Salaire",
  "Salaire conjoint",
  "AVS",
  "AI",
  "Pension",
  "Rentes",
  "Prestations complémentaires",
  "Allocations",
]);

function clamp(valeur: number, min = 0, max = 100): number {
  return Math.min(max, Math.max(min, valeur));
}

/**
 * Part (%) des revenus provenant de sources jugées stables (salariées,
 * sociales) plutôt que de sources plus volatiles (indépendant, locatif).
 * Heuristique simple et documentée, pensée pour être affinée plus tard.
 */
function calculerStabiliteRevenus(budget: Budget, totalRevenus: number): number {
  if (totalRevenus <= 0) return 100; // pas de revenu = neutre, ne pénalise pas le score
  const stable = budget.revenus.reduce((somme, l) => {
    if (!REVENUS_STABLES.has(l.nom)) return somme;
    return somme + versNombre(l.montant);
  }, 0);
  return clamp((stable / totalRevenus) * 100);
}

/**
 * Calcule le score de santé financière (0-100) et son libellé, à partir de
 * six sous-scores pondérés selon le référentiel actif. Purement
 * déterministe — aucune IA. C'est la pièce centrale de l'Analysis Engine.
 */
export function calculerScoreSante(
  budget: Budget,
  totaux: BudgetTotaux,
  referentiel: ReferentielBudgetaire
): ScoreSante {
  const poidsLogement = calculerPoidsLogement(totaux);
  const { fixes: poidsFixes } = calculerPoidsFixesVariables(totaux);
  const stabiliteRevenus = calculerStabiliteRevenus(budget, totaux.totalRevenus);

  const sousScores: SousScore[] = [
    {
      cle: "endettement",
      label: "Taux d'endettement",
      valeur: clamp(100 - totaux.tauxEndettement * (100 / referentiel.seuilEndettementRouge)),
      poids: referentiel.poidsScore.endettement,
    },
    {
      cle: "resteAVivre",
      label: "Reste à vivre",
      valeur: clamp((totaux.resteAVivreParPersonne / referentiel.resteAVivreConfortParPersonne) * 100),
      poids: referentiel.poidsScore.resteAVivre,
    },
    {
      cle: "epargne",
      label: "Taux d'épargne",
      valeur: clamp(totaux.tauxEpargne * 5), // 20% d'épargne => score plein
      poids: referentiel.poidsScore.epargne,
    },
    {
      cle: "chargesFixes",
      label: "Poids des charges fixes",
      valeur: clamp(100 - poidsFixes),
      poids: referentiel.poidsScore.chargesFixes,
    },
    {
      cle: "logement",
      label: "Poids du logement",
      valeur: clamp(100 - Math.max(0, poidsLogement - referentiel.poidsLogementMax) * 4),
      poids: referentiel.poidsScore.logement,
    },
    {
      cle: "stabiliteRevenus",
      label: "Stabilité des revenus",
      valeur: stabiliteRevenus,
      poids: referentiel.poidsScore.stabiliteRevenus,
    },
  ];

  const poidsTotal = sousScores.reduce((s, sc) => s + sc.poids, 0) || 1;
  const valeur = Math.round(
    sousScores.reduce((somme, sc) => somme + sc.valeur * sc.poids, 0) / poidsTotal
  );

  let niveau: NiveauSante;
  if (valeur >= referentiel.seuilsScore.excellent) niveau = "Excellent";
  else if (valeur >= referentiel.seuilsScore.bon) niveau = "Bon";
  else if (valeur >= referentiel.seuilsScore.fragile) niveau = "Fragile";
  else niveau = "Critique";

  return { valeur, niveau, detail: sousScores };
}
