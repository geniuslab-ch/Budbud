import type { Budget, BudgetTotaux } from "@/types/budget.types";
import type { Anomalie } from "@/types/analysis.types";
import type { ReferentielBudgetaire } from "@/config/referentielBudgetaire";
import { CATEGORIES_DEPENSES } from "@/utils/constants";
import { versMensuel } from "@/services/calculations/budgetCalculator";
import { versNombre } from "@/utils/formatters";
import { calculerPoidsLogement } from "./ratios";

/**
 * Détecte automatiquement une série d'anomalies budgétaires, à partir de
 * règles déterministes centralisées ici (aucune IA). Chaque règle est
 * paramétrée par le référentiel actif, jamais par une valeur codée en dur.
 * Ce sont ces anomalies que l'AI Engine utilisera plus tard comme matière
 * première pour ses recommandations.
 */
export function detecterAnomalies(
  budget: Budget,
  totaux: BudgetTotaux,
  referentiel: ReferentielBudgetaire
): Anomalie[] {
  const anomalies: Anomalie[] = [];

  // Dépenses inhabituellement élevées (hors logement, déjà couvert séparément).
  for (const categorie of CATEGORIES_DEPENSES) {
    if (categorie === "Logement") continue;
    for (const ligne of budget.depenses[categorie] ?? []) {
      const montantMensuel = versMensuel(ligne.montant, ligne.frequence);
      if (
        totaux.totalRevenus > 0 &&
        (montantMensuel / totaux.totalRevenus) * 100 > referentiel.seuilDepenseInhabituelle
      ) {
        anomalies.push({
          type: "depense_inhabituelle",
          niveau: "attention",
          titre: `Dépense élevée : ${ligne.nom || categorie}`,
          detail: `${Math.round(montantMensuel)} CHF/mois dans "${categorie}", soit plus de ${referentiel.seuilDepenseInhabituelle}% du revenu.`,
        });
      }
    }
  }

  // Cumul de lignes dans une même catégorie (typiquement les abonnements).
  for (const categorie of CATEGORIES_DEPENSES) {
    const lignes = budget.depenses[categorie] ?? [];
    if (lignes.length >= referentiel.seuilCumulLignes) {
      anomalies.push({
        type: "abonnements_multiples",
        niveau: "info",
        titre: `Cumul dans "${categorie}"`,
        detail: `${lignes.length} lignes enregistrées dans cette catégorie — une revue groupée peut révéler des doublons.`,
      });
    }
  }

  // Charge de dettes importante.
  if (totaux.tauxEndettement > referentiel.seuilEndettementRouge) {
    anomalies.push({
      type: "dettes_importantes",
      niveau: "critique",
      titre: "Charge de dettes importante",
      detail: `Les mensualités de dettes représentent ${Math.round(totaux.tauxEndettement)}% des revenus.`,
    });
  }

  // Reste à vivre insuffisant.
  if (totaux.resteAVivreParPersonne < referentiel.resteAVivreMinParPersonne) {
    anomalies.push({
      type: "reste_a_vivre_insuffisant",
      niveau: totaux.resteAVivreParPersonne < 0 ? "critique" : "attention",
      titre: "Reste à vivre insuffisant",
      detail: `${Math.round(totaux.resteAVivreParPersonne)} CHF par personne, sous le seuil de ${referentiel.resteAVivreMinParPersonne} CHF.`,
    });
  }

  // Taux d'endettement au sens large (déjà couvert par "dettes_importantes"
  // pour le seuil rouge) — ici on capte aussi la zone orange.
  if (
    totaux.tauxEndettement > referentiel.seuilEndettementOrange &&
    totaux.tauxEndettement <= referentiel.seuilEndettementRouge
  ) {
    anomalies.push({
      type: "endettement_eleve",
      niveau: "attention",
      titre: "Taux d'endettement à surveiller",
      detail: `${Math.round(totaux.tauxEndettement)}% des revenus partent dans le remboursement de dettes.`,
    });
  }

  // Logement disproportionné.
  const poidsLogement = calculerPoidsLogement(totaux);
  if (poidsLogement > referentiel.poidsLogementMax) {
    anomalies.push({
      type: "logement_disproportionne",
      niveau: poidsLogement > referentiel.poidsLogementMax + 10 ? "critique" : "attention",
      titre: "Logement disproportionné",
      detail: `Le logement représente ${Math.round(poidsLogement)}% des revenus, au-delà du repère de ${referentiel.poidsLogementMax}%.`,
    });
  }

  // Absence d'épargne malgré un solde positif.
  if (totaux.solde > 0 && totaux.tauxEpargne === 0) {
    anomalies.push({
      type: "absence_epargne",
      niveau: "info",
      titre: "Aucune épargne régulière",
      detail: "Une marge existe mais rien n'est mis de côté chaque mois.",
    });
  }

  // Dettes en retard ou en contentieux, une par une.
  for (const dette of budget.dettes) {
    if (dette.statut === "normal") continue;
    anomalies.push({
      type: "dette_en_difficulte",
      niveau: dette.statut === "contentieux" ? "critique" : "attention",
      titre: `Dette en ${dette.statut} : ${dette.nom || dette.creancier}`,
      detail: `Capital restant : ${Math.round(versNombre(dette.capitalRestant))} CHF. Statut : ${dette.statut}.`,
    });
  }

  return anomalies;
}
