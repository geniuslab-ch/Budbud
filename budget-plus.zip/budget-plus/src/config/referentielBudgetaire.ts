/**
 * Référentiel budgétaire — couche de configuration centralisant tous les
 * seuils utilisés par l'Analysis Engine. Rien n'est codé en dur ailleurs
 * dans l'application : un futur référentiel cantonal, une recommandation
 * d'organisme partenaire (Caritas, Dettes Conseils Suisse…) ou un profil
 * personnalisé peut remplacer ces valeurs sans toucher au moteur de calcul.
 *
 * Pour ajouter un référentiel alternatif : dupliquer cet objet, l'exposer
 * (ex. `referentielCantonVaud`), puis le sélectionner dans BudgetContext.
 */
export interface ReferentielBudgetaire {
  id: string;
  nom: string;

  /** Reste à vivre (CHF/mois) en dessous duquel une alerte se déclenche. */
  resteAVivreMinParPersonne: number;
  /** Reste à vivre "confortable" utilisé comme référence haute pour le score. */
  resteAVivreConfortParPersonne: number;

  /** Seuils du taux d'endettement (%). */
  seuilEndettementOrange: number;
  seuilEndettementRouge: number;

  /** Poids du logement dans le revenu (%) au-delà duquel il est jugé disproportionné. */
  poidsLogementMax: number;

  /** Nombre de lignes dans une catégorie à partir duquel on signale un cumul (ex. abonnements). */
  seuilCumulLignes: number;

  /** Part d'une dépense isolée dans le revenu (%) à partir de laquelle elle est jugée inhabituelle. */
  seuilDepenseInhabituelle: number;

  /** Pondérations du score de santé financière (doivent sommer à 100). */
  poidsScore: {
    endettement: number;
    resteAVivre: number;
    epargne: number;
    chargesFixes: number;
    logement: number;
    stabiliteRevenus: number;
  };

  /** Seuils (sur 100) des libellés du score de santé. */
  seuilsScore: {
    excellent: number;
    bon: number;
    fragile: number;
    // en dessous de `fragile` => "Critique"
  };
}

export const referentielSuisseParDefaut: ReferentielBudgetaire = {
  id: "ch-defaut",
  nom: "Référentiel Suisse — par défaut",
  resteAVivreMinParPersonne: 600,
  resteAVivreConfortParPersonne: 900,
  seuilEndettementOrange: 25,
  seuilEndettementRouge: 33,
  poidsLogementMax: 33,
  seuilCumulLignes: 4,
  seuilDepenseInhabituelle: 15,
  poidsScore: {
    endettement: 25,
    resteAVivre: 20,
    epargne: 15,
    chargesFixes: 15,
    logement: 15,
    stabiliteRevenus: 10,
  },
  seuilsScore: {
    excellent: 80,
    bon: 60,
    fragile: 40,
  },
};
